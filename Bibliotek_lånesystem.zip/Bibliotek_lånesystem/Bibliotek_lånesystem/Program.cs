﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibliotek_lånesystem
{
    class Program
    {
        // Sökfuktion för författare som vid träff returnerar vart i listan som den fick träff. 
        static int ListSokningAuthor(List<Book> lista, string searchAuthor)
        {
            for (int i = 0; i < lista.Count; i++)
            {
                if (lista[i].Author == searchAuthor)
                    return i;
            }
            return -1;
        }
        // Sökfunktion för boktitlar, fungerar på samma sätt som ovan. 
        static int ListSokningTitel(List<Book> lista, string searchTitle)
        {
            for (int i = 0; i < lista.Count; i++)
            {
                if (lista[i].Title == searchTitle)
                    return i;
            }
            return -1;
        }


        static void Main(string[] args)
        {
            List<Book> biblioteksLager = new List<Book>();
            string line;
            /* Kontrollera att sökvägen för .txt filen är den samma som nedan. Om inte: 
             * Alt 1) Flytta textfilen till platsen nedan.
             * Alt 2) Ändra filsökvägen i koden. 
             * För alternativ 2 krävs ocskå att skrivfilen (längre ner) får en speciferad plats som är samma som läsfilen (strax under). 
             * Just nu har den inte någon specificerad plats så by default läggs skriv filen alltid i Debug mappen.*/
            StreamReader readFile = new StreamReader(@"C:\Users\17mape\OneDrive\C#\Uppgifter\Projekt_LåneSystem_Bibliotek\Bibliotek_lånesystem\Bibliotek_lånesystem\bin\Debug\list.txt");
            // Läsfilen sorteras in i "biblioteksLager" listan vid uppstart av programmet. 
            // Villkoret nedan är att varje rad i textfilen (läsfilen) inte får vara tom (d.v.s. = null). 
            while ((line = readFile.ReadLine()) != null)
            {
                string[] sorter = line.Split(',');
                biblioteksLager.Add(new Book(sorter[0], sorter[1], sorter[2]));
            }
            readFile.Close();
            Console.WriteLine("Välkommen till online biblioteket!");
            int index, idInput;
            string searchTitle, searchAuthor;
            bool exitProgram = false;
            while (exitProgram == false)
            {
                Console.WriteLine("\nT söka på titel.\nF söka på författare.\nL låna bok.\nÅ återlämna bok.\nN registrera ny bok.\nB ta bort bok.\nA lista alla böcker.\nS sluta.");
                Console.Write("Vad vill du göra?\n>>");
                string answer = Console.ReadLine();

                switch (answer)
                {
                    case "T":
                    case "t":
                        Console.WriteLine("Ange titel du vill söka: ");
                        searchTitle = Console.ReadLine();
                        index = ListSokningTitel(biblioteksLager, searchTitle);

                        if (index == -1)
                            Console.WriteLine("Titeln hittades ej.");
                        else
                            biblioteksLager[index].Display();
                        break;
                    case "F":
                    case "f":
                        Console.WriteLine("Ange författare du vill söka: ");
                        searchAuthor = Console.ReadLine();
                        // det returnerade värdet i metoden "ListSokningAuthor" hamnar i variabeln "index".
                        index = ListSokningAuthor(biblioteksLager, searchAuthor);

                        if (index == -1)
                            Console.WriteLine("Författaren finns inte registrerad.");
                        else
                            biblioteksLager[index].Display();
                        break;
                    case "L":
                    case "l":
                        Console.WriteLine("Lediga böcker:");
                        for (int i = 0; i < biblioteksLager.Count; i++)
                        {
                            if (biblioteksLager[i].Status != "Upptagen")
                            {
                                Console.Write((i+1) + ")");
                                biblioteksLager[i].Display();
                            }
                        }
                        Console.WriteLine("Vilken bok vill du låna (ange id)?");
                        idInput = Convert.ToInt32(Console.ReadLine());

                        if (idInput >= 0 && idInput <= biblioteksLager.Count)
                        {
                            if (biblioteksLager[(idInput-1)].Status == "Upptagen")
                                Console.WriteLine("Boken är redan lånad.");
                            else
                            {
                                biblioteksLager[(idInput - 1)].Status = "Upptagen";
                                Console.WriteLine("Boken är nu lånad.");
                                // Uppdaterar filen ifall att användaren skulle stänga av programmet på fel sätt.
                                UpdateFile();
                            }
                        }
                        break;
                    case "Å":
                    case "å":
                        Console.WriteLine("Lånade böcker:");
                        for (int i = 0; i < biblioteksLager.Count; i++)
                        {
                            if (biblioteksLager[i].Status == "Upptagen")
                            {
                                Console.Write((i+1) + ")");
                                biblioteksLager[i].Display();
                            }
                        }
                        Console.WriteLine("Vilken bok vill du återlämna (ange id)?");
                        idInput = Convert.ToInt32(Console.ReadLine());
                        // "idUnput" får inte vara negativt eller större än vad det finns böcker i listan eftersom att variabeln används för att ange en plats i listan. Bryts detta krav får vi error.
                        if (idInput >= 0 && idInput <= biblioteksLager.Count)
                        {
                            if (biblioteksLager[(idInput - 1)].Status != "Upptagen")
                                Console.WriteLine("Boken är redan återlämnad.");
                            else
                            {
                                biblioteksLager[idInput - 1].Status = "Ledig";
                                Console.WriteLine("Boken är återlämnad.");
                                UpdateFile();
                            }
                        }
                        else
                            Console.WriteLine("Gick inte att hitta boken.");
                        break;
                    case "N":
                    case "n":
                        Console.Write("Ange författarens namn: ");
                        string authorName = Console.ReadLine();
                        Console.Write("Ange boktitel: ");
                        string titleName = Console.ReadLine();

                        biblioteksLager.Add(new Book(authorName, titleName, "Ledig"));
                        UpdateFile();
                        Console.WriteLine("Boken är nu registrerad!");
                        break;
                    case "B":
                    case "b":
                        Console.WriteLine("Ange titeln du vill ta bort: ");
                        searchTitle = Console.ReadLine();
                        index = ListSokningTitel(biblioteksLager, searchTitle);

                        if (index != -1)
                        {
                            if (biblioteksLager[index].Status != "Upptagen")
                            {
                                biblioteksLager.RemoveAt(index);
                                Console.WriteLine("Boken är nu avregistrerad!");
                                UpdateFile();
                            }
                            else
                                Console.WriteLine("Boken hittades men måste först återlämnas innan den kan avregistreras.");
                        }
                        else
                            Console.WriteLine("Titeln hittades ej!");
                        break;
                    case "A":
                    case "a":
                        for (int i = 0; i < biblioteksLager.Count; i++)
                        {
                            biblioteksLager[i].Display();
                        }
                        break;
                    case "S":
                    case "s":
                        exitProgram = true;
                        UpdateFile();
                        break;
                    default:
                        break;
                }
                if (exitProgram == true)
                    Console.WriteLine("\nVälkommen åter!");
                else
                    Console.WriteLine("\nTryck för att gå vidare...");
                Console.ReadLine();
            }
            void UpdateFile()
            {
                StreamWriter writeFile = new StreamWriter("list.txt");
                for (int i = 0; i < biblioteksLager.Count; i++)
                {
                    writeFile.WriteLine(biblioteksLager[i].Author + "," + biblioteksLager[i].Title + "," + biblioteksLager[i].Status);
                }
                writeFile.Close();
            }
        }
    }
}
