﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibliotek_lånesystem
{
    class Book
    {
        private string author, title, status;

        public Book(string a, string t, string s)
        {
            author = a;
            title = t;
            status = s;
        }

        public string Author
        {
            get { return author; }
            set { author = value; }
        }

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        public string Status
        {
            get { return status; }
            set { status = value; }
        }

        public void Display()
        {
            Console.WriteLine("\tTitel: " + title + "| Författare: " + author + "| Status: " + status);
        }
    }
}
